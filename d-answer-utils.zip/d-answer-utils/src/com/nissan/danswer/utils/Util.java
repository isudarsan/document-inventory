package com.nissan.danswer.utils;

import java.util.ListIterator;

import com.nissan.danswer.model.schedulecheck.DailyOCFList;
import com.nissan.danswer.model.schedulecheck.Order;
import com.nissan.danswer.model.schedulecheck.OrderList;
import com.nissan.danswer.model.schedulecheck.ScheduleList;
import com.nissan.danswer.model.schedulecheck.SpecOCFList;

public class Util {

	private OrderList orderList;
	private ScheduleList scheduleList;
	private DailyOCFList ocfList;
	private SpecOCFList specList;

	public Util(OrderList orderList, ScheduleList scheduleList, DailyOCFList ocfList, SpecOCFList specList) {
		super();
		this.orderList = orderList;
		this.scheduleList = scheduleList;
		this.ocfList = ocfList;
		this.specList = specList;
	}

	public void decideSortingOrder() {
		setWeekNoSortNull();
		setWeekNoSort();

		setDaySortNull();
		setDaySort();

		setWeekOfDueDateSortNull();
		setWeekOfDueDateSort();

		setInputDateOfOrderSortNull();
		setInputDateOfOrderSort();

		setDealerReplyFlgSortAcceptOrChange();
		setDealerReplyFlgSortHold();
		setDealerReplyFlgSortNull();

		setSortKey();

		for (Order order : orderList) {
			System.out.println(order);
		}

	}

	private void setSortKey() {
		ListIterator<Order> iterator = orderList.listIterator();
		while (iterator.hasNext()) {

			Order order = iterator.next();
			if (order.getSortKey() == null && order.getWeekNoSort() != null && order.getDaySort() != null
					&& order.getWeekOfDueDateSort() != null && order.getInputDateSort() != null
					&& order.getDealerReplySort() != null) {

				String key = "1" + order.getWeekNoSort() + order.getDaySort() + order.getWeekOfDueDateSort()
						+ order.getAllocationPriority() + order.getInputDateSort() + order.getDealerReplySort()
						+ order.getRandomNoZeroPadding();
				order.setSortKey(key);
				order.setDealerReplySort("1");
				iterator.remove();
				iterator.add(order);
			}

		}

	}

	private void setDealerReplyFlgSortAcceptOrChange() {

		ListIterator<Order> iterator = orderList.listIterator();
		while (iterator.hasNext()) {

			Order order = iterator.next();
			if (null == order.getDealerReplySort() && "H".equals(order.getDealerReplyFlg())) {
				order.setDealerReplySort("1");
				iterator.remove();
				iterator.add(order);
			}

		}
	}

	private void setDealerReplyFlgSortHold() {

		ListIterator<Order> iterator = orderList.listIterator();
		while (iterator.hasNext()) {

			Order order = iterator.next();
			if (null == order.getDealerReplySort() && "A".equals(order.getDealerReplyFlg())
					|| "C".equalsIgnoreCase(order.getDealerReplyFlg())) {
				order.setDealerReplySort("0");
				iterator.remove();
				iterator.add(order);
			}

		}
	}

	private void setDealerReplyFlgSortNull() {
		ListIterator<Order> iterator = orderList.listIterator();
		while (iterator.hasNext()) {

			Order order = iterator.next();
			if (null == order.getDealerReplySort() && null == order.getDealerReplyFlg()
					|| "".equalsIgnoreCase(order.getDealerReplyFlg())) {
				order.setDealerReplySort("9");
				iterator.remove();
				iterator.add(order);
			}

		}
	}

	private void setInputDateOfOrderSortNull() {
		ListIterator<Order> iterator = orderList.listIterator();
		while (iterator.hasNext()) {

			Order order = iterator.next();
			if (null == order.getInputDateSort() && null == order.getInputDateOfOrder()
					|| "".equalsIgnoreCase(order.getInputDateOfOrder())) {
				order.setInputDateSort("999999999999");
				iterator.remove();
				iterator.add(order);
			}

		}
	}

	private void setInputDateOfOrderSort() {
		ListIterator<Order> iterator = orderList.listIterator();
		while (iterator.hasNext()) {

			Order order = iterator.next();
			if (null == order.getInputDateSort() && null != order.getInputDateOfOrder()
					&& !"".equalsIgnoreCase(order.getInputDateOfOrder())) {
				order.setInputDateSort(order.getInputDateOfOrder());
				iterator.remove();
				iterator.add(order);
			}

		}
	}

	private void setWeekNoSortNull() {
		ListIterator<Order> iterator = orderList.listIterator();
		while (iterator.hasNext()) {

			Order order = iterator.next();
			if (null == order.getWeekNoSort() && null == order.getWeekNo() || "".equalsIgnoreCase(order.getWeekNo())) {
				order.setWeekNoSort("99");
				iterator.remove();
				iterator.add(order);
			}

		}

	}

	private void setWeekNoSort() {
		ListIterator<Order> iterator = orderList.listIterator();
		while (iterator.hasNext()) {

			Order order = iterator.next();
			if (null == order.getWeekNoSort() && null != order.getWeekNo() && !"".equalsIgnoreCase(order.getWeekNo())) {
				order.setWeekNoSort(order.getWeekNoSort());
				iterator.remove();
				iterator.add(order);
			}

		}

	}

	private void setDaySortNull() {
		ListIterator<Order> iterator = orderList.listIterator();
		while (iterator.hasNext()) {

			Order order = iterator.next();
			if (null == order.getDaySort() && null == order.getDay() || "".equals(order.getDay())) {
				order.setDaySort("99999999");
				iterator.remove();
				iterator.add(order);
			}

		}

	}

	private void setDaySort() {
		ListIterator<Order> iterator = orderList.listIterator();
		while (iterator.hasNext()) {

			Order order = iterator.next();
			if (null == order.getDaySort() && null != order.getDay() && !"".equals(order.getDay())) {
				order.setDaySort(order.getDay());
				iterator.remove();
				iterator.add(order);
			}

		}
	}

	private void setWeekOfDueDateSortNull() {
		ListIterator<Order> iterator = orderList.listIterator();
		while (iterator.hasNext()) {

			Order order = iterator.next();
			if (null == order.getWeekOfDueDateSort() && null == order.getWeekOfDueDateForDelivery()
					|| "".equals(order.getWeekOfDueDateForDelivery())) {
				order.setWeekOfDueDateSort("99");
				iterator.remove();
				iterator.add(order);
			}

		}
	}

	private void setWeekOfDueDateSort() {
		ListIterator<Order> iterator = orderList.listIterator();
		while (iterator.hasNext()) {

			Order order = iterator.next();
			if (null == order.getWeekOfDueDateSort() && null != order.getWeekOfDueDateForDelivery()
					&& !"".equals(order.getWeekOfDueDateForDelivery())) {
				order.setWeekOfDueDateSort(order.getWeekOfDueDateForDelivery());
				iterator.remove();
				iterator.add(order);
			}

		}
	}

}
