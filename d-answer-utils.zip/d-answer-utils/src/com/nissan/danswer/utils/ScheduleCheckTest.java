package com.nissan.danswer.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.logger.KnowledgeRuntimeLogger;
import org.drools.logger.KnowledgeRuntimeLoggerFactory;
//import org.drools.logger.KnowledgeRuntimeLogger;
//import org.drools.logger.KnowledgeRuntimeLoggerFactory;
import org.drools.runtime.StatefulKnowledgeSession;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.nissan.danswer.model.OCFIdentificationInfo;
import com.nissan.danswer.model.schedulecheck.SpecOCFList;
import com.nissan.danswer.model.schedulecheck.SpecOCF;
import com.nissan.danswer.model.schedulecheck.DailyOCFList;
import com.nissan.danswer.model.schedulecheck.DailyOCF;
import com.nissan.danswer.model.schedulecheck.MatchingResultList;
import com.nissan.danswer.model.schedulecheck.MatchingResult;
import com.nissan.danswer.model.schedulecheck.OrderList;
import com.nissan.danswer.model.schedulecheck.Order;
import com.nissan.danswer.model.schedulecheck.OrderOnlyList;
import com.nissan.danswer.model.schedulecheck.ScheduleList;
import com.nissan.danswer.model.schedulecheck.Schedule;
import com.nissan.danswer.model.schedulecheck.ScheduleOnlyList;

public class ScheduleCheckTest {

	private static String drlName = "D:\\code\\OTD_WS\\d-answer-utils\\rules\\ScheduleCheck.drl";

	private static String rfName = "D:\\code\\OTD_WS\\d-answer-utils\\ScheduleCheck.rf";

	private static KnowledgeBase kbase = null;

	// knowledge session
	private StatefulKnowledgeSession ksession;

	// logger
	private KnowledgeRuntimeLogger logger = null;

	public static void main(String args[]) throws Exception {

		new ScheduleCheckTest().simpleExecute();
	}

	public void simpleExecute() {
		try {

			KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();

			// add resources to KnowledgeBuilder
			// kbuilder.add(ResourceFactory.newFileResource(drlName))
			kbuilder.add(ResourceFactory.newFileResource(drlName), ResourceType.DRL);
			kbuilder.add(ResourceFactory.newFileResource(rfName), ResourceType.DRF);

			// knowledgeBuilderErrors
			KnowledgeBuilderErrors errors = kbuilder.getErrors();
			if (errors.size() > 0) {
				for (KnowledgeBuilderError error : errors) {
					System.err.println(error);
				}
				throw new IllegalArgumentException("Could not parse knowledge.");
			}

			// knowledgeBase
			kbase = KnowledgeBaseFactory.newKnowledgeBase();

			// add knowledgePackages to knowledgeBase
			kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());

			ksession = kbase.newStatefulKnowledgeSession();

			// input Fact list
			OrderList orderList = makeOrderList("order.csv");
			ScheduleList scheduleList = makeScheduleList("schedule.csv");
			DailyOCFList ocfList = makeDailyOcfList("daily_ocf.csv");
			SpecOCFList specList = makeSpecOcfList("spec_ocf.csv");

			Util util = new Util(orderList, scheduleList, ocfList, specList);
			util.decideSortingOrder();

		} catch (Exception e) {
			// fail(e.getMessage());
			e.printStackTrace();
		}
	}

	public static DailyOCFList makeDailyOcfList(String filename) throws Exception {
		String data[] = new String[13];
		DailyOCFList list = new DailyOCFList();
		try {
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			while ((line = bufferedreader.readLine()) != null) {
				data = line.split(",", -1);
				list.add(setDailyOCF(data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8],
						data[9], data[10], Integer.valueOf(data[11]).intValue(), Integer.valueOf(data[12]).intValue()));
			}
			filereader.close();
		} catch (Exception e) {
			System.out.println(filename + ":err");
			throw e;
		}

		return list;
	}

	// Schedule
	public static ScheduleList makeScheduleList(String filename) throws Exception {
		String data[] = new String[11];
		ScheduleList list = new ScheduleList();
		try {
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			while ((line = bufferedreader.readLine()) != null) {
				data = line.split(",", -1);
				list.add(setSchedule(data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8],
						data[9], data[10]));
			}
			filereader.close();
		} catch (Exception e) {
			System.out.println(filename + ":err");
			throw e;
		}

		return list;
	}

	// SPEC_OCF
	public static SpecOCFList makeSpecOcfList(String filename) throws Exception {
		String data[] = new String[12];
		SpecOCFList list = new SpecOCFList();
		try {
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			int i = 0;
			while ((line = bufferedreader.readLine()) != null) {
				// System.out.println("Start line at " + i);
				data = line.split(",", -1);
				if (i > 0 && list.get(i - 1).getPlanYearMonth().equals(data[0])
						&& list.get(i - 1).getCarSeries().equals(data[1])
						&& list.get(i - 1).getPorCode().equals(data[2])
						&& list.get(i - 1).getProductionFamilyCode().equals(data[3])
						&& list.get(i - 1).getEndItemModelCode().equals(data[4])
						&& list.get(i - 1).getEndItemColorCode().equals(data[5])
						&& list.get(i - 1).getWeekNo().equals(data[11])) {
					list.get(i - 1).getOcfList().add(setOcfInfo(data[6], data[7], data[8], data[9], data[10]));
				} else {
					list.add(setSpecOCF(data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8],
							data[9], data[10], data[11]));
					i++;
				}
			}
			// System.out.println(i+"a");
			filereader.close();
		} catch (Exception e) {
			System.out.println(filename + ":err");
			throw e;
		}

		return list;
	}

	// ORDER_INFO
	public static OrderList makeOrderList(String filename) throws Exception {
		String data[] = new String[18];
		OrderList list = new OrderList();
		try {
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			while ((line = bufferedreader.readLine()) != null) {
				data = line.split(",", -1);
				list.add(setOrder(data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8],
						data[9], data[10], data[11], data[12], data[13], Integer.valueOf(data[14]).intValue(), data[15],
						data[16], data[17]));
			}
			filereader.close();
		} catch (Exception e) {
			System.out.println(filename + ":err");
			throw e;
		}

		return list;
	}

	private MatchingResultList makeMatchingResultList(String filename) throws Exception {
		String data[] = new String[22];
		MatchingResultList list = new MatchingResultList();
		try {
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			while ((line = bufferedreader.readLine()) != null) {
				data = line.split(",", -1);
				list.add(setResult(data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8],
						data[9], data[10], data[11], data[12], data[13], Integer.valueOf(data[14]).intValue(), data[15],
						data[16], data[17], data[18], data[19], data[20], data[21]));
			}
			filereader.close();
		} catch (Exception e) {
			System.out.println(filename + ":err");
			throw e;
		}

		return list;
	}

	private MatchingResult setResult(String ym, String car, String por, String family, String model, String color,
			String productionOrderNo, String dealerCode, String orderType, String accountNo, String allocationPriority,
			String inputDateOfOrder, String weekOfDue, String dealerReplyFlg, int randomNo, String distributionNo,
			String weekNo, String day, String factory, String line, String newNo, String offDatePlan) {

		MatchingResult result = new MatchingResult();
		result.setPlanYearMonth(ym);
		result.setCarSeries(car);
		result.setPorCode(por);
		result.setProductionFamilyCode(family);
		result.setEndItemModelCode(model);
		result.setEndItemColorCode(color);
		result.setProductionOrderNo(productionOrderNo);
		result.setDealerCode(dealerCode);
		result.setOrderType(orderType);
		result.setAccountNo(accountNo);
		result.setAllocationPriority(allocationPriority);
		result.setInputDateOfOrder(inputDateOfOrder);
		result.setWeekOfDueDateForDelivery(weekOfDue);
		result.setDealerReplyFlg(dealerReplyFlg);
		result.setRandomNo(randomNo);
		result.setDistributionNo(distributionNo);
		result.setFactoryCode(factory);
		result.setLineClass(line);
		result.setNewProductionOrderNo(newNo);
		result.setOffDatePlan(offDatePlan);
		result.setWeekNo(weekNo);
		result.setDay(day);

		return result;
	}

	public static DailyOCF setDailyOCF(String ym, String car, String weekNo, String day, String factory, String line,
			String sort, String ocfClass, String loc, String group, String frame, int maxQty, int actualQty) {

		DailyOCF ocf = new DailyOCF();
		ocf.setPlanYearMonth(ym);
		ocf.setCarSeries(car);
		ocf.setWeekNo(weekNo);
		ocf.setDay(day);
		ocf.setFactoryCode(factory);
		ocf.setLineClass(line);
		ocf.setOcfInfo(setOcfInfo(sort, ocfClass, loc, group, frame));
		ocf.setMaxQty(maxQty);
		ocf.setActualQty(actualQty);

		return ocf;
	}

	public static OCFIdentificationInfo setOcfInfo(String sort, String ocfClass, String loc, String group,
			String frame) {

		OCFIdentificationInfo ocfInfo = new OCFIdentificationInfo();
		ocfInfo.setFrameSortCode(sort);
		ocfInfo.setOcfClassificationCode(ocfClass);
		ocfInfo.setLocationIdentificationCode(loc);
		ocfInfo.setCarGroup(group);
		ocfInfo.setFrameCode(frame);

		return ocfInfo;
	}

	public static SpecOCF setSpecOCF(String ym, String car, String por, String family, String model, String color,
			String sort, String ocfclass, String loc, String group, String frame, String weekNo) {

		SpecOCF spec = new SpecOCF();
		spec.setPlanYearMonth(ym);
		spec.setCarSeries(car);
		spec.setPorCode(por);
		spec.setProductionFamilyCode(family);
		spec.setEndItemModelCode(model);
		spec.setEndItemColorCode(color);
		spec.setWeekNo(weekNo);

		List<OCFIdentificationInfo> ocfList = new ArrayList<OCFIdentificationInfo>();
		ocfList.add(setOcfInfo(sort, ocfclass, loc, group, frame));

		spec.setOcfList(ocfList);

		return spec;
	}

	public static Order setOrder(String ym, String car, String por, String family, String model, String color,
			String productionOrderNo, String dealerCode, String orderType, String accountNo, String allocationPriority,
			String inputDateOfOrder, String weekOfDue, String dealerReplyFlg, int randomNo, String distributionNo,
			String weekNo, String day) {

		Order orderInfo = new Order();
		orderInfo.setPlanYearMonth(ym);
		orderInfo.setCarSeries(car);
		orderInfo.setPorCode(por);
		orderInfo.setProductionFamilyCode(family);
		orderInfo.setEndItemModelCode(model);
		orderInfo.setEndItemColorCode(color);
		orderInfo.setProductionOrderNo(productionOrderNo);
		orderInfo.setDealerCode(dealerCode);
		orderInfo.setOrderType(orderType);
		orderInfo.setAccountNo(accountNo);
		orderInfo.setAllocationPriority(allocationPriority);
		orderInfo.setInputDateOfOrder(inputDateOfOrder);
		orderInfo.setWeekOfDueDateForDelivery(weekOfDue);
		orderInfo.setDealerReplyFlg(dealerReplyFlg);
		orderInfo.setRandomNo(randomNo);
		orderInfo.setDistributionNo(distributionNo);
		orderInfo.setWeekNo(weekNo);
		orderInfo.setDay(day);

		return orderInfo;
	}

	private static Schedule setSchedule(String ym, String car, String por, String family, String model, String color,
			String factoy, String line, String newNo, String offDatePlan, String weekNo) {

		Schedule schedule = new Schedule();
		schedule.setPlanYearMonth(ym);
		schedule.setCarSeries(car);
		schedule.setProductionFamilyCode(family);
		schedule.setPorCode(por);
		schedule.setEndItemModelCode(model);
		schedule.setEndItemColorCode(color);
		schedule.setFactoryCode(factoy);
		schedule.setLineClass(line);
		schedule.setNewProductionOrderNo(newNo);
		schedule.setOffDatePlan(offDatePlan);
		schedule.setWeekNo(weekNo);

		return schedule;
	}

	private void checkOcfResult(DailyOCFList expected, DailyOCFList actual) {

		assertTrue(actual.size() > 0);

		assertEquals(expected.size(), actual.size());

		for (int idx = 0; idx < actual.size(); idx++) {
			assertEquals(expected.get(idx).getPlanYearMonth(), actual.get(idx).getPlanYearMonth());
			assertEquals(expected.get(idx).getCarSeries(), actual.get(idx).getCarSeries());
			assertEquals(expected.get(idx).getWeekNo(), actual.get(idx).getWeekNo());
			assertEquals(expected.get(idx).getDay(), actual.get(idx).getDay());
			assertEquals(expected.get(idx).getFactoryCode(), actual.get(idx).getFactoryCode());
			assertEquals(expected.get(idx).getLineClass(), actual.get(idx).getLineClass());
			assertEquals(expected.get(idx).getOcfInfo().getFrameSortCode(),
					actual.get(idx).getOcfInfo().getFrameSortCode());
			assertEquals(expected.get(idx).getOcfInfo().getOcfClassificationCode(),
					actual.get(idx).getOcfInfo().getOcfClassificationCode());
			assertEquals(expected.get(idx).getOcfInfo().getLocationIdentificationCode(),
					actual.get(idx).getOcfInfo().getLocationIdentificationCode());
			assertEquals(expected.get(idx).getOcfInfo().getCarGroup(), actual.get(idx).getOcfInfo().getCarGroup());
			assertEquals(expected.get(idx).getOcfInfo().getFrameCode(), actual.get(idx).getOcfInfo().getFrameCode());
			assertEquals(expected.get(idx).getMaxQty(), actual.get(idx).getMaxQty());
			assertEquals(expected.get(idx).getActualQty(), actual.get(idx).getActualQty());
		}
	}

	private class MatchingResultComparator implements Comparator<Object> {

		@Override
		public int compare(Object o1, Object o2) {
			try {
				MatchingResult lhs = (MatchingResult) o1;
				MatchingResult rhs = (MatchingResult) o2;
				if (lhs.getCarSeries().compareTo(rhs.getCarSeries()) == 0) {
					return lhs.getProductionOrderNo().compareTo(rhs.getProductionOrderNo());
				} else {
					return lhs.getCarSeries().compareTo(rhs.getCarSeries());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return 0;
		}

	}

	private void checkMatchingResult(MatchingResultList expected, MatchingResultList actual) {

		assertTrue(actual.size() > 0);

		assertEquals(expected.size(), actual.size());

		Collections.sort(expected, new MatchingResultComparator());
		Collections.sort(actual, new MatchingResultComparator());

		for (int idx = 0; idx < actual.size(); idx++) {
			assertEquals(expected.get(idx).getPlanYearMonth(), actual.get(idx).getPlanYearMonth());
			assertEquals(expected.get(idx).getCarSeries(), actual.get(idx).getCarSeries());
			assertEquals(expected.get(idx).getProductionFamilyCode(), actual.get(idx).getProductionFamilyCode());
			assertEquals(expected.get(idx).getPorCode(), actual.get(idx).getPorCode());
			assertEquals(expected.get(idx).getEndItemModelCode(), actual.get(idx).getEndItemModelCode());
			assertEquals(expected.get(idx).getEndItemColorCode(), actual.get(idx).getEndItemColorCode());
			assertEquals(expected.get(idx).getProductionOrderNo(), actual.get(idx).getProductionOrderNo());
			assertEquals(expected.get(idx).getDealerCode(), actual.get(idx).getDealerCode());
			assertEquals(expected.get(idx).getOrderType(), actual.get(idx).getOrderType());
			assertEquals(expected.get(idx).getAccountNo(), actual.get(idx).getAccountNo());
			assertEquals(expected.get(idx).getAllocationPriority(), actual.get(idx).getAllocationPriority());
			assertEquals(expected.get(idx).getInputDateOfOrder(), actual.get(idx).getInputDateOfOrder());
			assertEquals(expected.get(idx).getWeekOfDueDateForDelivery(),
					actual.get(idx).getWeekOfDueDateForDelivery());
			assertEquals(expected.get(idx).getDealerReplyFlg(), actual.get(idx).getDealerReplyFlg());
			assertEquals(expected.get(idx).getRandomNo(), actual.get(idx).getRandomNo());
			assertEquals(expected.get(idx).getFactoryCode(), actual.get(idx).getFactoryCode());
			assertEquals(expected.get(idx).getLineClass(), actual.get(idx).getLineClass());
			assertEquals(expected.get(idx).getNewProductionOrderNo(), actual.get(idx).getNewProductionOrderNo());
			assertEquals(expected.get(idx).getOffDatePlan(), actual.get(idx).getOffDatePlan());
			assertEquals(expected.get(idx).getDistributionNo(), actual.get(idx).getDistributionNo());
			assertEquals(expected.get(idx).getWeekNo(), actual.get(idx).getWeekNo());
			assertEquals(expected.get(idx).getDay(), actual.get(idx).getDay());
		}

	}

	private class OrderComparator implements Comparator<Object> {

		@Override
		public int compare(Object o1, Object o2) {
			try {
				Order lhs = (Order) o1;
				Order rhs = (Order) o2;
				if (lhs.getCarSeries().compareTo(rhs.getCarSeries()) == 0) {
					return lhs.getProductionOrderNo().compareTo(rhs.getProductionOrderNo());
				} else {
					return lhs.getCarSeries().compareTo(rhs.getCarSeries());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return 0;
		}

	}

	private void checkOrderResult(OrderList expected, OrderOnlyList actual) {

		assertTrue(actual.size() > 0);

		Collections.sort(expected, new OrderComparator());
		Collections.sort(actual, new OrderComparator());

		for (int idx = 0; idx < actual.size(); idx++) {
			assertEquals(expected.get(idx).getPlanYearMonth(), actual.get(idx).getPlanYearMonth());
			assertEquals(expected.get(idx).getCarSeries(), actual.get(idx).getCarSeries());
			assertEquals(expected.get(idx).getProductionFamilyCode(), actual.get(idx).getProductionFamilyCode());
			assertEquals(expected.get(idx).getPorCode(), actual.get(idx).getPorCode());
			assertEquals(expected.get(idx).getEndItemModelCode(), actual.get(idx).getEndItemModelCode());
			assertEquals(expected.get(idx).getEndItemColorCode(), actual.get(idx).getEndItemColorCode());
			assertEquals(expected.get(idx).getProductionOrderNo(), actual.get(idx).getProductionOrderNo());
			assertEquals(expected.get(idx).getDealerCode(), actual.get(idx).getDealerCode());
			assertEquals(expected.get(idx).getOrderType(), actual.get(idx).getOrderType());
			assertEquals(expected.get(idx).getAccountNo(), actual.get(idx).getAccountNo());
			assertEquals(expected.get(idx).getAllocationPriority(), actual.get(idx).getAllocationPriority());
			assertEquals(expected.get(idx).getInputDateOfOrder(), actual.get(idx).getInputDateOfOrder());
			assertEquals(expected.get(idx).getWeekOfDueDateForDelivery(),
					actual.get(idx).getWeekOfDueDateForDelivery());
			assertEquals(expected.get(idx).getDealerReplyFlg(), actual.get(idx).getDealerReplyFlg());
			assertEquals(expected.get(idx).getRandomNo(), actual.get(idx).getRandomNo());
			assertEquals(expected.get(idx).getWeekNo(), actual.get(idx).getWeekNo());
			assertEquals(expected.get(idx).getDay(), actual.get(idx).getDay());
		}

	}

	private class ScheduleComparator implements Comparator<Object> {

		@Override
		public int compare(Object o1, Object o2) {
			try {
				Schedule lhs = (Schedule) o1;
				Schedule rhs = (Schedule) o2;
				if (lhs.getCarSeries().compareTo(rhs.getCarSeries()) == 0) {
					return lhs.getNewProductionOrderNo().compareTo(rhs.getNewProductionOrderNo());
				} else {
					return lhs.getCarSeries().compareTo(rhs.getCarSeries());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return 0;
		}

	}

	private void checkSheduleResult(ScheduleList expected, ScheduleOnlyList actual) {

		assertTrue(actual.size() > 0);

		Collections.sort(expected, new ScheduleComparator());
		Collections.sort(actual, new ScheduleComparator());

		for (int idx = 0; idx < actual.size(); idx++) {
			assertEquals(expected.get(idx).getPlanYearMonth(), actual.get(idx).getPlanYearMonth());
			assertEquals(expected.get(idx).getCarSeries(), actual.get(idx).getCarSeries());
			assertEquals(expected.get(idx).getProductionFamilyCode(), actual.get(idx).getProductionFamilyCode());
			assertEquals(expected.get(idx).getPorCode(), actual.get(idx).getPorCode());
			assertEquals(expected.get(idx).getEndItemModelCode(), actual.get(idx).getEndItemModelCode());
			assertEquals(expected.get(idx).getEndItemColorCode(), actual.get(idx).getEndItemColorCode());
			assertEquals(expected.get(idx).getFactoryCode(), actual.get(idx).getFactoryCode());
			assertEquals(expected.get(idx).getLineClass(), actual.get(idx).getLineClass());
			assertEquals(expected.get(idx).getNewProductionOrderNo(), actual.get(idx).getNewProductionOrderNo());
			assertEquals(expected.get(idx).getOffDatePlan(), actual.get(idx).getOffDatePlan());
			assertEquals(expected.get(idx).getWeekNo(), actual.get(idx).getWeekNo());
		}

	}

}
